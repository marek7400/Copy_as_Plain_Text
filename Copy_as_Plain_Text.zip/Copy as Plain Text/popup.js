document.addEventListener('DOMContentLoaded', function() {
  var checkbox = document.getElementById('enableExtension');
  var shortcutInput = document.getElementById('shortcut');

  // Wczytywanie zapisanych ustawień
  chrome.storage.sync.get(['enabled', 'shortcut'], function(data) {
    checkbox.checked = data.enabled !== false;
    shortcutInput.value = data.shortcut || '';
  });

  // Zapisywanie stanu włączenia/wyłączenia
  checkbox.addEventListener('change', function() {
    chrome.storage.sync.set({enabled: checkbox.checked}, function() {
      console.log('Zapisano stan: ' + checkbox.checked);
    });
  });

  // Zapisywanie skrótu klawiaturowego
  shortcutInput.addEventListener('change', function() {
    chrome.storage.sync.set({shortcut: shortcutInput.value}, function() {
      console.log('Zapisano skrót: ' + shortcutInput.value);
    });
  });
});
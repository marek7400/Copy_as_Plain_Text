chrome.commands.onCommand.addListener((command) => {
  if (command === "toggle_extension") {
    chrome.storage.sync.get('enabled', function(data) {
      const newState = !data.enabled;
      chrome.storage.sync.set({enabled: newState}, function() {
        console.log('Zmieniono stan na: ' + newState);
      });
    });
  }
});
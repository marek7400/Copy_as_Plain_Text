let isEnabled = true;
let shortcut = '';

function handleCopy(e) {
  if (!isEnabled) return;
  e.preventDefault();
  let text = window.getSelection().toString();
  e.clipboardData.setData('text/plain', text);
  
  // Dodajemy powiadomienie
  showNotification("Text copied to clipboard WITHOUT FORMATTING");
}

function showNotification(message) {
  let notification = document.createElement('div');
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    border-radius: 4px;
    z-index: 9999;
    font-family: Arial, sans-serif;
    font-size: 14px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
  `;
  document.body.appendChild(notification);
  
  // Usuń powiadomienie po 3 sekundach
  setTimeout(() => {
    document.body.removeChild(notification);
  }, 3000);
}

function toggleExtension() {
  isEnabled = !isEnabled;
  updateListener();
  chrome.storage.sync.set({enabled: isEnabled}, function() {
    console.log('Zmieniono stan na: ' + isEnabled);
  });
}

chrome.storage.sync.get(['enabled', 'shortcut'], function(data) {
  isEnabled = data.enabled !== false;
  shortcut = data.shortcut || '';
  updateListener();
});

chrome.storage.onChanged.addListener(function(changes, namespace) {
  if (namespace === 'sync') {
    if ('enabled' in changes) {
      isEnabled = changes.enabled.newValue;
      updateListener();
    }
    if ('shortcut' in changes) {
      shortcut = changes.shortcut.newValue;
    }
  }
});

function updateListener() {
  document.removeEventListener('copy', handleCopy);
  if (isEnabled) {
    document.addEventListener('copy', handleCopy);
  }
}

document.addEventListener('keydown', function(e) {
  if (shortcut) {
    const keys = shortcut.toLowerCase().split('+');
    const pressedKeys = [];
    if (e.ctrlKey) pressedKeys.push('ctrl');
    if (e.shiftKey) pressedKeys.push('shift');
    if (e.altKey) pressedKeys.push('alt');
    pressedKeys.push(e.key.toLowerCase());

    if (keys.every(key => pressedKeys.includes(key)) && pressedKeys.length === keys.length) {
      toggleExtension();
      e.preventDefault();
    }
  }
});

// Inicjalne dodanie listenera
updateListener();